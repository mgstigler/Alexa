"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Alexa = require("alexa-sdk");
let sessionState = false;
const games_1 = require("./Services/games");
let crosswordAnswer = "";
let triviaAnswer = "";
module.exports.FamilyFun = (event, context, callback) => {
    let alexa = Alexa.handler(event, context, callback);
    console.info(JSON.stringify(event));
    alexa.registerHandlers(handlers);
    alexa.execute();
};
let handlers = {
    //Handles the launch request
    'LaunchRequest': function () {
        this.emit(':ask', 'Welcome to Family Fun, your personal app for all the fun you could ask for.  Say next to get started?', 'Ask for the next task to get started?');
    },
    'NextRequest': function () {
        games_1.gamesService.getIndex(5, index => {
            console.info("Number: " + index);
            games_1.gamesService.getGameInformation(index, "Games", gameinformation => {
                if (index == 1) {
                    games_1.gamesService.getGameInformation(index, "Categories", category => {
                        this.emit(':tell', 'The game is ' + gameinformation.Game + '. ' + gameinformation.Description + ". the category is " + category.Category, 'The game is ' + gameinformation.Game + '. ' + gameinformation.Description + " the category is " + category.Category);
                    });
                }
                else if (index == 2) {
                    games_1.gamesService.getGameInformation(index, "Rhyming", rhyme => {
                        this.emit(':tell', 'The game is ' + gameinformation.Game + '. ' + gameinformation.Description + ". the word to rhyme with is " + rhyme.Word, 'The game is ' + gameinformation.Game + '. ' + gameinformation.Description + " the word to rhyme with is " + rhyme.Word);
                    });
                }
                else if (index == 3) {
                    games_1.gamesService.getGameInformation(index, "Crossword", crossword => {
                        crosswordAnswer = crossword.Answer;
                        this.emit(':ask', 'The game is ' + gameinformation.Game + '. ' + gameinformation.Description + ". the hint is " + crossword.Hint + ". The answer is " + crossword.Letters + " letters long.", 'The game is ' + gameinformation.Game + '. ' + gameinformation.Description + " the hint is " + crossword.Hint + " The answer is " + crossword.Letters + " letters long.  To answer, say The answer is.");
                    });
                }
                else if (index == 4) {
                    games_1.gamesService.getGameInformation(index, "Trivia", trivia => {
                        triviaAnswer = trivia.Answer;
                        this.emit(':ask', 'The game is ' + gameinformation.Game + '. ' + gameinformation.Description + trivia.Trivia, 'The game is ' + gameinformation.Game + '. ' + gameinformation.Description + ". Ask for the answer by saying whats the answer.  " + trivia.Trivia);
                    });
                }
                else {
                    games_1.gamesService.getGameInformation(index, "Players", player => {
                        this.emit(':tell', 'Do an impression of ' + player.Player);
                    });
                }
            });
        });
    },
    'CrosswordAnswer': function () {
        let answer = this.event.request.intent.slots.answer.value;
        if (answer == crosswordAnswer) {
            this.emit(':tell', 'You are correct!  The answer is ' + crosswordAnswer);
        }
        else {
            this.emit(':tell', 'The answer is ' + crosswordAnswer);
        }
    },
    'TriviaAnswer': function () {
        this.emit(':tell', 'The answer is ' + triviaAnswer);
    },
    'AMAZON.StopIntent': function () {
        // State Automatically Saved with :tell
        this.emit(':tell', `Goodbye.`);
    },
    'AMAZON.CancelIntent': function () {
        // State Automatically Saved with :tell
        this.emit(':tell', `Goodbye.`);
    },
    'AMAZON.HelpIntent': function () {
        this.emit(':ask', `What would you like to do?`, `What would you like to do?`);
    },
    'Unhandled': function () {
        this.emit(':ask', `What would you like to do?`, `What would you like to do?`);
    }
};
//# sourceMappingURL=handler.js.map