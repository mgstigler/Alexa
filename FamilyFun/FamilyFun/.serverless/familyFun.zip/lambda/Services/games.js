'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = require("aws-sdk");
let docClient = new AWS.DynamoDB.DocumentClient();
class GamesService {
    getGameInformation(gameNumber, table, callback) {
        let params = {
            TableName: table,
            Key: {
                "Index": gameNumber
            }
        };
        let response = {
            statusCode: 200,
            message: ""
        };
        docClient.get(params, function (err, data) {
            if (err) {
                console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
                response.statusCode = 500;
                response.message = "Cannot find item ";
                callback(null);
            }
            else if (data == null) {
                response.statusCode = 404;
                response.message = "Cannot find item ";
                callback(data.Item);
            }
            else {
                console.log("GetItem succeeded:", JSON.stringify(data, null, 2));
                response.statusCode = 200;
                response.message = "Slot retrieved: " + JSON.stringify(data);
                callback(data.Item);
            }
        });
    }
    getIndex(totalNumber, callback) {
        totalNumber += 1;
        let index = Math.random() * (totalNumber - 1) + 1;
        let wholeNumber = index.toString().split(".")[0];
        callback(parseInt(wholeNumber));
    }
}
exports.GamesService = GamesService;
exports.gamesService = new GamesService();
//# sourceMappingURL=games.js.map