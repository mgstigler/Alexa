var compliments = [
	{
		"old school" : [	
			"You're as cute as a bug's ear.",
			"You're a flutter bum.",
			"You're a regular Oliver Twist!"
			]
	},
	{
		"odd" : [
			"A day without you is like the Teenage Mutant Ninja Turtles without their ninja training.  Actually that's not true because they'd still be life-size turtles with the ability to talk, and that is so rare and cool.  So a day without you is more like a day with a frustrated Shredder.",
			"If, for some reason, our airplane was experiencing problems, I would help you with your oxygen mask before adjusting mine.  And that's against sky code.",
			"You're smarter than Google and Mary Poppins combined.",
			"Your confidence is so impressive, you could walk into Mordor and everyone would be like, yep that makes sense.",
			"I just want to hang out with you and blow bubbles under the sea, like spongebob and patrick. But yeah, we can do other stuff too.",
			"Out of all of my friends, you are definitely the best at being single.",
			"Your eyes are so fierce, it's like I'm looking at Beyonce strut.",
			"Everytime I look at you, I'm just like 'That's so Raven'.",
			"I believe in you, like I believe that deer hooves are really just tiny little gloves for their tiny little deer hands.", 
			"You're so hot, you could dress up as cee lo green and still look good",
			"I would save a seat for you.  Which is not that big of a deal, unless the game is musical chairs.  Which this is!  Welcome to the game room!",
			"If you were running for President, I would vote for you. And clear your search history.  Because politics is a dirty business, and they will dig that shit up.  But don't worry, I got you.",
			"You make me happier than when I see a well-groomed moustache.",
			"You inspire me. And strangers, probably.  Also friends and stalkers. You are an inspiration to many!"
		]
	}
];

exports.compliments = compliments;