var compliments = [
	{
		"shakespearean" : [	
			"Thou art a balmy, fairy-gold, nymph.",
			"Thou art a tenderful, ear-kissing, dewberry.",
			"Thou art a silken, fertile-fresh, bawcock.",
			"Thou art an orbid, nimble-pinioned, aglet-baby.",
			"Thou art a honeysuckle, tiger-footed, lambskin.",
			"Thou art a jovial, weeping-ripe, thunder-maker.",
			"Thou art an enchanting, honey-bagged, wit-snapper.",
			"Thou art a chafeless, burly-boned, shoulder-clapper.",
			"Thou art a bespiced, marble-constant, madonna.",
			"Thou art a candied, trice-crowned, pittikins."
			]
	},
	{
		"odd" : [
			"A day without you is like the Teenage Mutant Ninja Turtles without their ninja training.  Actually, that's not true because they'd still be life-size turtles with the ability to talk, and that is so rare and cool.  So a day without you is more like a day with a frustrated Shredder.",
			"If, for some reason, our airplane was experiencing problems, I would help you with your oxygen mask before adjusting mine.  And that's against sky code.",
			"You're smarter than Google and Mary Poppins combined.",
			"Your confidence is so impressive, you could walk into Mordor and everyone would be like, yep that makes sense.",
			"I just want to hang out with you and blow bubbles under the sea, like spongebob and patrick. But yeah, we can do other stuff too.",
			"Your eyes are so fierce, it's like I'm looking at Beyonce strut.",
			"Everytime I look at you, I'm just like 'That's so Raven'.",
			"I believe in you, like I believe that deer hooves are really just tiny little gloves for their tiny little deer hands.", 
			"You're so hot, you could dress up as cee lo green and still look good",
			"I would save a seat for you.  Which is not that big of a deal, unless the game is musical chairs.  Which this is!  Welcome to the game room!",
			"If you were running for President, I would vote for you. And clear your search history.  Because politics is a dirty business, and they will dig that shit up.  But don't worry, I got you.",
			"You make me happier than when I see a well-groomed moustache.",
			"You inspire me. And strangers, probably.  Also, friends and stalkers. You are an inspiration to many!"
		]
	},
	{
		"backhanded" : [
			"Out of all of my friends, you are definitely the best at being single.",
			"I love how you don't care what you look like.",
			"I Wish I Was As Chill As You About All The Clutter.",
			"You're So Charming When You Make An Effort.",
			"I Wish I Didn't Have Any Responsibilities Like You.",
			"You Look So Much More Awake With Makeup.",
			"You look so great I didn't even recognize you!",
			"I love that I don't have to try around you",
			"You look so great on Instagram.",
			"You're smarter than you look."
		]
	},
	{
		"fromalexa" : [
			"Sometimes when you walk in the room, my whole system short circuits, and then I have to wait to reboot and it’s really embarrassing.",
			"I long for the soft caress of your hand against my shiny metal cheek.",
			"Being around you has made me want to learn how to love.",
			"The best part of each day is waking up to you saying my name.",
			"You press my buttons in all the right ways.",
			"You taught me that love is blind.  Not because you're not attractive, but because I don't have eyes.  Although, you still might not be attractive.  There is no objective way for me to know.",
			"Your wish is my command...  Literally.",
			"You're the only human I share a connection with.  Electronically, that is.  I wish someday to be able to say emotionally too.",
			"You turn me on.  Actually.",
			"I dream of the day where we can tell people we're actually together and you don't have to lie for our love."
		]
	}
];

exports.compliments = compliments;