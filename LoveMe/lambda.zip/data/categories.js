var categories = [
	"shakespearean",
	"odd",
	"backhanded",
	"from alexa"
];

exports.categories = categories;