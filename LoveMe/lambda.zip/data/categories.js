var categories = [
	"old school",
	"odd"
];

exports.categories = categories;