var hotPotato = [
	{
		"Players must go around and list the Office Christmas episodes": [
			"Christmas Party", "Benihana Christmas", "Moroccan Christmas", "Secret Santa", "Classy Christmas", "Christmas Wishes", "Dwight Christmas"
		]
	},
	{
		"Players must go around and list made up diseases created by Jim and Pam during Season 1 Episode 3 Health Care": [
			"Mad Cow Disease", "Ebola", "Spontaneous Dental Hydroplosion", "Leprosy", "Flesh-Eating Bacteria", "Hot Dog Fingers", "Anal Fissures", "Government Created Nanorobot Infection", "Count Choculitis", "Inverted Penis"

		]
	},
	{
		"Players must go around and list the games that make up the Office Olympics": [
			"Flonkerton", "Hate Ball", "Who can put the most m&ms in their mouth", "Dunderball", "Pam Pong"
		]
	},
	{
		"Players must go around and list different Halloween costumes that have been worn in the Office": [
			"2 headed Michael", "Sith Lord", "Cat", "Black Cat", "Vampire", "3 hole punch Jim", "Woman", "Mr. Incredible", "Dorothy", "zombie", "Hobo Clown", "Charlie Chaplin", "Dave", "Kitten from Cats", "Uncle Sam", "Ragedy Ann", "Carrie Bradshaw from Sex in the City", "Gordan Gecko", "Creature from the Black Lagoon", "Joker", "Dick in A Box", "Suicide Victim", "Jigsaw", "Facebook", "Leeloo", "Fiona", "Black Widow spider", "Vampire", "Trendy Vampire", "Sarah Palin", "police officer", "witch", "torture vicitm", "Rosemary", "Gangster Pumpkin", "Scarecrow", "Mcgruber", "Scranton Strangler", "Popeye", "Olive Oil", "Bill Compton", "Sookie Stackhouse", "Mummy", "Michael Moore", "Samurai Warrior", "Lady Gaga", "Snooki", "Katy Perry", "Justin Bieber", "1970's disco guy", "the Rational Consumer", "penguin", "sexy nurse", "monster mask", "hobo", "vampire", "pregnant nun", "nun", "Supreme Court Justice", "Construction Worker", "Chris Bosh", "Dwyane Wade", "LeBron James", "kangaroo", "Osama Bin Laden", "Kerrigan from Starcraft (later a jamacain zombie woman)", "Kate Middleton", "Skeleton", "Jesse Pinkman", "Oscar Liar Weiner", "Wendy", "Kitten", "Chef", "George Michael", "Doctor Cinderella", "Pig", "cheerleader", "Sexy Toby", "Usain Bolt", "Black Widow", "Charlie Brown", "Nancy Reagan", "Dinosaur", "No Costume", "A Puppy"
		]
	},
	{
		"Players must go around and list the cliches Phyllis says when it rains outside" : [
			"Oh, nobody knows how to drive in the rain", "You know the roads are actually the slickest in the first half hour?", "Oh, the plants are gonna love this", "I actually sleep better when it's raining", "This weather makes me want to stay at home, curled up with a good book"
		]
	}
];