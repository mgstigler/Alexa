//List of trivia questions for TRIVIA with answers
var triviaQuestions = [
	{
		"What are Michael's initials?": [
			"MGS"
		]
	},
	{
		"Whose mom does Michael date?" : [
			"Pam"
		]
	},
	{
		"What farm item does Dwight sell?" : [
			"beets"
		]
	}
];