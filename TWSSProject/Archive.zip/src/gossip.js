var gossip = [
	{
		"1" : [
			"Most likely to set a fire while cooking a cheese pita"
		]
	},
	{
		"2" : [
			"Most likely to get beat up by a 13-year-old girl."
		]
	},
	{
		"3" : [
			"Most likely to set one's hair on fire in a drunken state of being."
		]
	},
	{
		"4" : [
			"Most likely to have a nanny cam set up to monitor their household of cats while at work."
		]
	},
	{
		"5" : [
			"Most likely to sleep with a friend's mom."
		]
	},
	{
		"6" : [
			"Most likely to get naked at a boss's pool party."
		]
	},
	{
		"7": [
			"Most likely to skip out on a double date valentine's lunch to have sex in the bathroom."
		]
	},
	{
		"8": [
			"Most likely to hire a hitman to knock out kneecaps with a lead pipe."
		]
	},
	{
		"9": [
			"Most likely to own the nickname 'boner champ'."
		]
	},
	{
		"10": [
			"Most likely to get a boob job."
		]
	}
];