'use strict';

// Include the json files//
var hotPotato = require('./hotPotato');
var triviaQuestions = require('./triviaQuestions');
var gossip = require('./gossip');

exports.handler = function (event, context) {
    try {
        console.log("event.session.application.applicationId=" + event.session.application.applicationId);

        /**
         * Uncomment this if statement and populate with your skill's application ID to
         * prevent someone else from configuring a skill that sends requests to this function.
         */

//     if (event.session.application.applicationId !== "amzn1.echo-sdk-ams.app.05aecccb3-1461-48fb-a008-822ddrt6b516") {
//         context.fail("Invalid Application ID");
//      }

        if (event.session.new) {
            onSessionStarted({requestId: event.request.requestId}, event.session);
        }

        if (event.request.type === "LaunchRequest") {
            onLaunch(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "IntentRequest") {
            onIntent(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "SessionEndedRequest") {
            onSessionEnded(event.request, event.session);
            context.succeed();
        }
    } catch (e) {
        context.fail("Exception: " + e);
    }
};

/**
 * Called when the session starts.
 */
function onSessionStarted(sessionStartedRequest, session) {
    console.log("onSessionStarted requestId=" + sessionStartedRequest.requestId
        + ", sessionId=" + session.sessionId);

    // add any session init logic here
}

/**
 * Called when the user invokes the skill without specifying what they want.
 */
function onLaunch(launchRequest, session, callback) {
    console.log("onLaunch requestId=" + launchRequest.requestId
        + ", sessionId=" + session.sessionId);

    getWelcomeResponse(callback);
}

/**
 * Called when the user specifies an intent for this skill.
 */
function onIntent(intentRequest, session, callback) {
    console.log("onIntent requestId=" + intentRequest.requestId
        + ", sessionId=" + session.sessionId);

    var intent = intentRequest.intent,
        intentName = intentRequest.intent.name;

    // handle yes/no intent after the user has been prompted
    if (session.attributes && session.attributes.userPromptedToContinue) {
        delete session.attributes.userPromptedToContinue;
        if ("AMAZON.NoIntent" === intentName) {
            handleFinishSessionRequest(intent, session, callback);
        } else if ("AMAZON.YesIntent" === intentName) {
            handleRepeatRequest(intent, session, callback);
        }
    }

    // dispatch custom intents to handlers here
    if ("AnswerIntent" === intentName) {
        handleAnswerRequest(intent, session, callback);
    } else if ("AnswerOnlyIntent" === intentName) {
        handleAnswerRequest(intent, session, callback);
    } else if ("DontKnowIntent" === intentName) {
        handleAnswerRequest(intent, session, callback);
    } else if ("AMAZON.YesIntent" === intentName) {
        handleAnswerRequest(intent, session, callback);
    } else if ("AMAZON.NoIntent" === intentName) {
        handleAnswerRequest(intent, session, callback);
    } else if ("AMAZON.StartOverIntent" === intentName) {
        getWelcomeResponse(callback);
    } else if ("AMAZON.RepeatIntent" === intentName) {
        handleRepeatRequest(intent, session, callback);
    } else if ("AMAZON.HelpIntent" === intentName) {
            handleGetHelpRequest(intent, session, callback);
    } else if ("AMAZON.StopIntent" === intentName) {
        handleFinishSessionRequest(intent, session, callback);
    } else if ("AMAZON.CancelIntent" === intentName) {
        handleFinishSessionRequest(intent, session, callback);
    } 
}

/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session) {
    console.log("onSessionEnded requestId=" + sessionEndedRequest.requestId
        + ", sessionId=" + session.sessionId);

    // Add any cleanup logic here
}

// ------- Skill specific business logic -------

var GAME_LENGTH = 15;
// Be sure to change this for your skill.
var CARD_TITLE = "That's What She Said"; 


function getWelcomeResponse(callback) {
    // Be sure to change this for your skill.
    var sessionAttributes = {},
        //CHANGE THIS TEXT
        speechOutput = "Welcome to That's What She Said, the fun and interactive Office drinking game. I will prompt you with several drinking tasks.  When you have completed the current task and are ready for the next task, say 'Next'. Let's begin. ",
        shouldEndSession = false,
        repromptText = spokenQuestion,

    speechOutput += repromptText;
    sessionAttributes = {
        "speechOutput": repromptText,
        "repromptText": repromptText
    };
    callback(sessionAttributes,
        buildSpeechletResponse(CARD_TITLE, speechOutput, repromptText, shouldEndSession));
}


//-------- This function starts the Hot Potato Game --------------------//
function startHotPotato() {
	speechOutput = "In this game, players will be presented with a category.  They will go around listing items that belong to that category until the timer goes off.  Whoever is caught when the timer goes off, loses and has to chug for five seconds";
	var length = hotPotato.hotPotato.length();
	var index = Math.random() * (length);
	speechOutput = hotPotato.hotPotato[index];
}

//---------This function starts the trivia questions game --------------//
function startTrivia() {
	speechOutput = "Trivia competition, losing team drinks";
}


//---------This function starts the gossip game --------------//
function startGossip() {
	speechOutput = "Trivia competition, losing team drinks";
}

//---------This function starts the women's appreciation game --------------//
function startWomensAppreciation() {
	speechOutput = "Girls drink";
}

//---------This function starts the warehouse game --------------//
function startWarehouse(){
	speechOutput = "Men Drink";
}

//---------This function starts the impish or admirable game --------------//
function startImpishOrAdmirable() {
	speechOutput = "One player decides what is impish (You're impish if you've...) Drink if you're impish, assign a drink if you're admirable";
}

//---------This function starts the Dream Team game --------------//
function startDreamTeam(){
	speechOutput = "Choose a mate to drink with you until told otherwise";
}

//---------This function starts the desert island game --------------//
function startDesertIsland() {
	speechOutput = "In this game, one player decides a desert island category, the other players must go around and list items in that cateogry. First player to be stumped drinks for five seconds";
}

//---------This function starts the dinner party game --------------//
function startDinnerParty() {
	speechOutput = "In this game, one person is named as the host.  The host makes up a rule that players must follow for the remainder of the dinner party";
}

//---------This function starts the email surveillance game --------------//
function startEmailSurveillance() {
	speechOutput = "In this game, one player is assigned the role of assassin, if they wink at you, you have been assassinated and must drink your drink, you then become the assassin until Alexa tells you otherwise";
}

//---------This function starts the casual friday game --------------//
function startCasualFriday() {
	speechOutput = "One player picks an article of clothing that another player has to take off for an undetermined amount of time";
}

//---------This function starts the threat level midnight game --------------//
function startThreatLevelMidnight() {
	speechOutput = "Take a sip everytime you hear the word Scarn";
}

//---------This function starts the free family portrait game --------------//
function startFreeFamilyPortrait() {
	speechOutput = "Alexa lists people to take a selfie together and send via snapchat";
}

//---------This function starts the koi pond game --------------//
function startKoiPond() {
	speechOutput = "Waterfall";
}


//---------This function starts the booze cruise game --------------//
function startBoozeCruise() {
	speechOutput = "A person is named Captain.  They can assign life vests to all but one passenger on the ship.  All assigned life jackets, take a sip, the one without takes a shot. Sip sip shot";
}



function isAnswerSlotValid(intent) {
    var answerSlotFilled = intent.slots && intent.slots.Answer && intent.slots.Answer.value;
    var answerSlotIsInt = answerSlotFilled && !isNaN(parseInt(intent.slots.Answer.value));
    return 1;
}

//-------Don't edit these functions, they are used to handle requests and session ending ----------------//

function handleRepeatRequest(intent, session, callback) {
    // Repeat the previous speechOutput and repromptText from the session attributes if available
    // else start a new game session
    if (!session.attributes || !session.attributes.speechOutput) {
        getWelcomeResponse(callback);
    } else {
        callback(session.attributes,
            buildSpeechletResponseWithoutCard(session.attributes.speechOutput, session.attributes.repromptText, false));
    }
}

function handleGetHelpRequest(intent, session, callback) {
    // Set a flag to track that we're in the Help state.
    if (session.attributes) {
        session.attributes.userPromptedToContinue = true;
    } else {
        // In case user invokes and asks for help simultaneously.
        session.attributes = { userPromptedToContinue: true };
    }
    
    // Do not edit the help dialogue. This has been created by the Alexa team to demonstrate best practices.

    var speechOutput = "To start a new game at any time, say, start new game. "
        + "To repeat the last element, say, repeat. "
        + "Would you like to keep playing?",
        repromptText = "Try to get the right answer. "
        + "Would you like to keep playing?";
        var shouldEndSession = false;
    callback(session.attributes,
        buildSpeechletResponseWithoutCard(speechOutput, repromptText, shouldEndSession));
}

function handleFinishSessionRequest(intent, session, callback) {
    // End the session with a custom closing statment when the user wants to quit the game
    callback(session.attributes,
        buildSpeechletResponseWithoutCard("Thanks for playing That's What She Said!", "", true));
}


// ------- Helper functions to build responses -------


function buildSpeechletResponse(title, output, repromptText, shouldEndSession) {
    return {
        outputSpeech: {
            type: "PlainText",
            text: output
        },
        card: {
            type: "Simple",
            title: title,
            content: output
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: repromptText
            }
        },
        shouldEndSession: shouldEndSession
    };
}

function buildSpeechletResponseWithoutCard(output, repromptText, shouldEndSession) {
    return {
        outputSpeech: {
            type: "PlainText",
            text: output
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: repromptText
            }
        },
        shouldEndSession: shouldEndSession
    };
}

function buildResponse(sessionAttributes, speechletResponse) {
    return {
        version: "1.0",
        sessionAttributes: sessionAttributes,
        response: speechletResponse
    };
}
