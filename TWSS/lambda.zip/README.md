# That's What She Said Getting Started

## Skill Description

This is a fun The Office themed drinking game.  It features a variety of mini games that are shuffled and read aloud by Alexa. 

This game should be played in a group of people (specifically fans of NBC's The Office, although it is not completely necessary to be able to enjoy the game).  One person in the group will start by invoking Alexa.  She will then shuffle through a series of mini games and present them to the group.  Some of the mini games are specific to the user whose turn it is, some are group games.  Pass your turn to the next player by saying "Next".

Some of the games include Office trivia questions, hot potato, categories, never have I ever and several more.  Right now there are about 60 trivia questions, 15 mini games, and many categories and prompts for the players.  Most of the trivia questions are pulled from "https://www.sporcle.com/games/enough/theoffice"

The game ends whenever the players decide they are done.   The hope is that you leave satisfied and smiling.

...that's what she said

## Games
- HOT POTATO - In this game, a timer will be set for one minute, whoever is caught when the timer goes off, loses and has to chug for five seconds 

	1. Players must go around and list the Office Christmas episodes
		(Answers: Christmas Party, Benihana Christmas, Moroccan Christmas, Secret Santa, Classy Christmas, Christmas Wishes, Dwight Christmas)

	2. Players must go around and list made up diseases created by Jim and Pam during Season 1 Episode 3 "Health Care"
		(Answers: Mad Cow Disease, Ebola, Spontaneous Dental Hydroplosion, Leprosy, Flesh-Eating Bacteria, Hot Dog Fingers, Anal Fissures, Government Created Nanorobot Infection, Count Choculitis, Inverted Penis)

	3. Players must go around and list the games that make up the Office Olympics
		(Answers: Flonkerton, Hate Ball, Who can put the most m&ms in their mouth, Dunderball, Pam Pong)

	4. Players must go around and list different Halloween costumes that have been worn in the Office
		(Answers: 2 headed Michael, Sith Lord, Cat, Black Cat, Vampire, 3 hole punch Jim, Woman, Mr. Incredible, Dorothy, zombie, Hobo Clown, Charlie Chaplin, "Dave", Kitten from Cats, Uncle Sam, Ragedy Ann, Carrie Bradshaw from Sex in the City, Gordan Gecko, Creature from the Black Lagoon, Joker, Dick in A Box, Suicide Victim, Jigsaw, Facebook, Leeloo, Fiona, Black Widow spider, "Original" Vampire, "Trendy" Vampire, Sarah Palin, police officer, witch, torture vicitm, Rosemary, "Gangster" Pumpkin, Scarecrow, Mcgruber, Scranton Strangler, Popeye, Olive Oil, Bill Compton, Sookie Stackhouse, Mummy, Michael Moore, Samurai Warrior, Lady Gaga, Snooki, Katy Perry, Justin Bieber, 1970's disco guy, the "Rational Consumer", penguin, sexy nurse, monster mask, hobo, vampire, pregnant nun, nun, Supreme Court Justice, Construction Worker, Chris Bosh, Dwyane Wade, LeBron James, kangaroo, Osama Bin Laden, Kerrigan from Starcraft (later a jamacain zombie woman), Kate Middleton, Skeleton, Jesse Pinkman, Oscar Liar Weiner, Wendy, Kitten, Chef, George Michael, Doctor Cinderella, Pig, cheerleader, "Sexy" Toby, Usain Bolt, Black Widow, Charlie Brown, Nancy Reagan, Dinosaur, No Costume, A Puppy)

	5. Players must go around and list the cliches Phyllis says when it rains outside
		(Answers: Oh, nobody knows how to drive in the rain, You know the roads are actually the slickest in the first half hour?, Oh, the plants are gonna love this, I actually sleep better when it's raining, This weather makes me want to stay at home, curled up with a good book)


- WOMEN'S APPRECIATION - Girls drink


- IMPISH OR ADMIRABLE - One player decides what is impish (You're impish if you've...) Drink if you're impish, assign a drink if you're admirable


- DREAM TEAM - Choose a mate to drink with you until told otherwise//


- DESERT ISLAND - In this game, one player decides a desert island category, the other players must go around and list items in that cateogry. First player to be stumped drinks for five seconds



- EMAIL SURVEILLANCE - In this game, one player is assigned the role of assassin, if they wink at you, you have been assassinated and must drink your drink, you then become the assassin until Alexa tells you otherwise


- CASUAL FRIDAY - One player picks an article of clothing that another player has to take off for an undetermined amount of time


- DINNER PARTY - In this game, one person is named as the host.  The host makes up a rule that players must follow for the remainder of the dinner party


- THREAT LEVEL MIDNIGHT - Never have I ever


- FREE FAMILY PORTRAIT STUDIO - Alexa lists people to take a selfie together and send via snapchat


- KOI POND - Waterfall


- TRIVIA - Trivia competition, losing team drinks

	
- THE WAREHOUSE - Men Drink


- GOSSIP - Most likely to.  Drink for number of fingers pointed your way
	1. Most likely to set a fire while cooking a cheese pita.
	2. Most likely to get beat up by a 13-year-old girl.
	3. Most likely to set one's hair on fire in a drunken state of being.
	4. Most likely to have a nanny cam set up to monitor their household of cats while at work.
	5. Most likely to sleep with a friend's mom.
	6. Most likely to get naked at a boss's pool party.
	7. Most likely to skip out on a double date valentine's lunch to have sex in the bathroom.
	8. Most likely to hire a hitman to knock out kneecaps with a lead pipe.
	9. Most likely to own the nickname 'boner champ'.
	10. Most likely to win a dance party



- BOOZE CRUISE - A person is named Captain.  They can assign life vests to all but one passenger on the ship.  All assigned life jackets, take a sip, the one without takes a shot. Sip sip shot




